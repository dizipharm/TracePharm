import 'package:flutter/material.dart';

const Color themeColor = Color(0xFF044281);
