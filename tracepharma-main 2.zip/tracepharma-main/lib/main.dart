import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:tracepharm/providers/location_provider.dart';
import 'package:tracepharm/providers/main_provider.dart';
import 'package:tracepharm/screens/home.dart';
import 'package:tracepharm/screens/login.dart';
import 'package:tracepharm/screens/splash_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
        providers: [
          ChangeNotifierProvider(create: (context) => LocationProvider()),
          ChangeNotifierProvider(create: (context) => MainProvider()),
        ],
        builder: (context, _) {
          return Consumer<MainProvider>(builder: (context, mainprovider, _) {
            return MaterialApp(
              title: 'TracePharma',
              theme: ThemeData(
                primarySwatch: Colors.blue,
              ),
              routes: {
                '/': (BuildContext ctx) => const SplashScreen(),
                '/home': (BuildContext ctx) => const HomePage(),
                '/login': (BuildContext ctx) => const LoginPage(),
              },
            );
          });
        });
  }
}
