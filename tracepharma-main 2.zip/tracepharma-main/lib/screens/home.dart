import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:tracepharm/const.dart';
import 'package:tracepharm/model/login_success_response.dart';
import 'package:tracepharm/providers/location_provider.dart';
import 'package:tracepharm/providers/main_provider.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late MainProvider _mainProvider;
  late LoginSuccessResponse _loginSuccessResponse;
  late LocationProvider _locationController;
  @override
  void initState() {
    super.initState();
    _mainProvider = Provider.of<MainProvider>(context, listen: false);
    _locationController = Provider.of<LocationProvider>(context, listen: false);
    getUserData();
  }

  getUserData() async {
    _loginSuccessResponse = await _mainProvider.getValuesFromSharedPref();

    setState(() {
      _locationController.getLocationData();
    });
  }

  @override
  Widget build(BuildContext context) {
    final double width = MediaQuery.of(context).size.width;
    final double height = MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: AppBar(
        elevation: 0.0,
        actions: [
          Expanded(
              child: Row(
            children: [
              IconButton(
                icon: const Icon(
                  Icons.location_on,
                  color: themeColor,
                ),
                onPressed: () {
                  _locationController.getLocationData();
                },
              ),
              Text(
                _locationController.currentLocation,
                style: const TextStyle(
                  color: themeColor,
                ),
              ),
            ],
          )),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Image.asset('assets/logo2.png'),
          ),
        ],
        backgroundColor: Colors.transparent,
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              _loginSuccessResponse.firstName != null
                  ? "Hello,${_loginSuccessResponse.firstName}"
                  : "Loading...",
              style: TextStyle(fontSize: 30),
            ),
            SizedBox(
              height: 10,
            ),
            Text(
              _loginSuccessResponse.firstName != null
                  ? "${_loginSuccessResponse.companyName}"
                  : "Loading...",
              style: TextStyle(fontSize: 20),
            ),
            Text(
              "${_loginSuccessResponse.organizationCategory}",
              style: TextStyle(fontSize: 15),
            ),
            Text(
              "Role -${_loginSuccessResponse.roleType}",
              style: TextStyle(fontSize: 15),
            ),
            Text(
              "${_loginSuccessResponse.contactNumber}",
              style: TextStyle(fontSize: 15),
            ),
            SizedBox(
              height: height * 0.20,
            ),
            TextButton.icon(
              onPressed: () {},
              icon: const Icon(
                Icons.qr_code_scanner,
                color: Colors.white,
              ),
              style: ButtonStyle(
                backgroundColor:
                    MaterialStateProperty.resolveWith((states) => themeColor),
                minimumSize: MaterialStateProperty.resolveWith(
                  (states) => Size(width, height * 0.08),
                ),
              ),
              label: const Text(
                "Scan Product QR/Barcode",
                style: TextStyle(color: Colors.white),
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            const Align(
              alignment: Alignment.center,
              child: Text(
                "OR",
                style: TextStyle(fontSize: 15),
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            TextField(
              decoration: InputDecoration(
                  border: const OutlineInputBorder(
                      borderSide: BorderSide(color: themeColor)),
                  suffixIcon: InkWell(
                      onTap: () {
                        Navigator.pushNamed(context, '/details');
                      },
                      child: const Icon(Icons.search_rounded)),
                  hintText: "Enter Code (GTIN or SSCC) Number"),
            ),
            const Expanded(child: SizedBox()),
            Expanded(
              child: Align(
                  alignment: Alignment.center,
                  child: Image.asset('assets/poweredby.png')),
            )
          ],
        ),
      ),
    );
  }
}
