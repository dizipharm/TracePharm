import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:tracepharm/const.dart';
import 'package:tracepharm/providers/main_provider.dart';

class SplashScreen extends StatelessWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final MainProvider _mainProvider =
        Provider.of<MainProvider>(context, listen: false);
    Future.delayed(const Duration(seconds: 3), () async {
      if (await _mainProvider.checkIsLoggedIn()) {
        Navigator.pushReplacementNamed(context, '/home');
      } else {
        Navigator.pushReplacementNamed(context, '/login');
      }
    });
    return Scaffold(
      body: Container(
        height: double.infinity,
        width: double.infinity,
        color: themeColor,
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Image.asset('assets/logo.png'),
              const SizedBox(height: 40),
              Image.asset('assets/poweredby.png'),
            ],
          ),
        ),
      ),
      floatingActionButton: const CircularProgressIndicator(
        color: Colors.white,
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
    );
  }
}
