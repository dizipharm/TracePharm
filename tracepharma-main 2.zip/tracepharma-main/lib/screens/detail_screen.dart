import 'package:flutter/material.dart';
import 'package:tracepharm/const.dart';
import 'package:tracepharm/model/package_details.dart';

class DetailScreen extends StatelessWidget {
  const DetailScreen({Key? key, required this.packageDetailsResponse})
      : super(key: key);
  final PackageDetailsResponse packageDetailsResponse;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.transparent,
        iconTheme: const IconThemeData(color: Colors.black),
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Image.asset('assets/logo2.png'),
          ),
        ],
      ),
      body: Column(
        children: [
          Card(
            child: Column(
              children: [
                Text(packageDetailsResponse.track.packageInformation[0]
                    .packageInformation.packageType),
                Text(packageDetailsResponse
                    .track.packageInformation[0].packageInformation.lotNumber),
                Text(packageDetailsResponse
                    .track.packageInformation[0].packageInformation.ssccNo),
                Text(packageDetailsResponse.track.packageInformation[0]
                    .packageInformation.packageGrossWeight),
                Text(packageDetailsResponse.track.packageInformation[0]
                    .packageInformation.totalDimensions),
                Text(
                    "${packageDetailsResponse.track.packageInformation[0].packageInformation.innerSerailCount}"),
                Text(packageDetailsResponse
                    .track.packageInformation[0].packageInformation.colour),
                const Text('Last updated on'),
              ],
            ),
          ),
          Row(
            children: [
              Container(
                height: 50,
                width: 50,
                decoration: BoxDecoration(
                  color: themeColor,
                  borderRadius: BorderRadius.circular(10.0),
                ),
                child: const Icon(
                  Icons.event_note_outlined,
                ),
              )
            ],
          )
        ],
      ),
    );
  }
}
