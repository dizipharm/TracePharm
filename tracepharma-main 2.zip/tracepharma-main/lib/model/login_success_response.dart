// To parse this JSON data, do
//
//     final loginSuccessResponse = loginSuccessResponseFromMap(jsonString);

import 'dart:convert';

LoginSuccessResponse loginSuccessResponseFromMap(String str) =>
    LoginSuccessResponse.fromMap(json.decode(str));

String loginSuccessResponseToMap(LoginSuccessResponse data) =>
    json.encode(data.toMap());

class LoginSuccessResponse {
  LoginSuccessResponse({
    required this.message,
    required this.email,
    required this.firstName,
    required this.lastName,
    required this.contactNumber,
    required this.alternateContactNumber,
    required this.id,
    required this.access,
    required this.role,
    required this.roleType,
    required this.companyName,
    required this.companyAddress,
    required this.organizationCategory,
    required this.organizationId,
    required this.companyGln,
  });

  final String message;
  final String email;
  final String firstName;
  final String lastName;
  final String contactNumber;
  final String alternateContactNumber;
  final String id;
  final String access;
  final String role;
  final String roleType;
  final String companyName;
  final String companyAddress;
  final String organizationCategory;
  final String organizationId;
  final String companyGln;

  factory LoginSuccessResponse.fromMap(Map<String, dynamic> json) =>
      LoginSuccessResponse(
        message: json["message"],
        email: json["email"],
        firstName: json["first_name"],
        lastName: json["last_name"],
        contactNumber: json["contact_number"],
        alternateContactNumber: json["alternate_contact_number"],
        id: json["id"],
        access: json["access"],
        role: json["role"],
        roleType: json["role_type"],
        companyName: json["company_name"],
        companyAddress: json["company_address"],
        organizationCategory: json["organization_category"],
        organizationId: json["organization_id"],
        companyGln: json["company_gln"],
      );

  Map<String, dynamic> toMap() => {
        "message": message,
        "email": email,
        "first_name": firstName,
        "last_name": lastName,
        "contact_number": contactNumber,
        "alternate_contact_number": alternateContactNumber,
        "id": id,
        "access": access,
        "role": role,
        "role_type": roleType,
        "company_name": companyName,
        "company_address": companyAddress,
        "organization_category": organizationCategory,
        "organization_id": organizationId,
        "company_gln": companyGln,
      };
}
