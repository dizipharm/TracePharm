// To parse this JSON data, do
//
//     final packageDetailsResponse = packageDetailsResponseFromMap(jsonString);

import 'dart:convert';

PackageDetailsResponse packageDetailsResponseFromMap(String str) =>
    PackageDetailsResponse.fromMap(json.decode(str));

String packageDetailsResponseToMap(PackageDetailsResponse data) =>
    json.encode(data.toMap());

class PackageDetailsResponse {
  PackageDetailsResponse({
    required this.responseTime,
    required this.track,
  });

  final List<dynamic> responseTime;
  final Track track;

  factory PackageDetailsResponse.fromMap(Map<String, dynamic> json) =>
      PackageDetailsResponse(
        responseTime: List<dynamic>.from(json["response_time"].map((x) => x)),
        track: Track.fromMap(json["track"]),
      );

  Map<String, dynamic> toMap() => {
        "response_time": List<dynamic>.from(responseTime.map((x) => x)),
        "track": track.toMap(),
      };
}

class Track {
  Track({
    required this.controllConditions,
    required this.gtinInformation,
    required this.locations,
    required this.owner,
    required this.packageInformation,
    required this.status,
    required this.transactionEvent,
  });

  final List<List<ControllCondition>> controllConditions;
  final List<GtinInformationElement> gtinInformation;
  final List<List<LocationTP>> locations;
  final List<Owner> owner;
  final List<PackageInformationElement> packageInformation;
  final List<Status> status;
  final List<TransactionEvent> transactionEvent;

  factory Track.fromMap(Map<String, dynamic> json) => Track(
        controllConditions: List<List<ControllCondition>>.from(
            json["controll_conditions"].map((x) => List<ControllCondition>.from(
                x.map((x) => ControllCondition.fromMap(x))))),
        gtinInformation: List<GtinInformationElement>.from(
            json["gtin_information"]
                .map((x) => GtinInformationElement.fromMap(x))),
        locations: List<List<LocationTP>>.from(json["locations"].map(
            (x) => List<LocationTP>.from(x.map((x) => LocationTP.fromMap(x))))),
        owner: List<Owner>.from(json["owner"].map((x) => Owner.fromMap(x))),
        packageInformation: List<PackageInformationElement>.from(
            json["package_information"]
                .map((x) => PackageInformationElement.fromMap(x))),
        status: List<Status>.from(json["status"].map((x) => Status.fromMap(x))),
        transactionEvent: List<TransactionEvent>.from(
            json["transaction_event"].map((x) => TransactionEvent.fromMap(x))),
      );

  Map<String, dynamic> toMap() => {
        "controll_conditions": List<dynamic>.from(controllConditions
            .map((x) => List<dynamic>.from(x.map((x) => x.toMap())))),
        "gtin_information":
            List<dynamic>.from(gtinInformation.map((x) => x.toMap())),
        "locations": List<dynamic>.from(
            locations.map((x) => List<dynamic>.from(x.map((x) => x.toMap())))),
        "owner": List<dynamic>.from(owner.map((x) => x.toMap())),
        "package_information":
            List<dynamic>.from(packageInformation.map((x) => x.toMap())),
        "status": List<dynamic>.from(status.map((x) => x.toMap())),
        "transaction_event":
            List<dynamic>.from(transactionEvent.map((x) => x.toMap())),
      };
}

class ControllCondition {
  ControllCondition({
    required this.controllCondition,
  });

  final TransactionStatus controllCondition;

  factory ControllCondition.fromMap(Map<String, dynamic> json) =>
      ControllCondition(
        controllCondition:
            TransactionStatus.fromMap(json["controll_condition"]),
      );

  Map<String, dynamic> toMap() => {
        "controll_condition": controllCondition.toMap(),
      };
}

class TransactionStatus {
  TransactionStatus();

  factory TransactionStatus.fromMap(Map<String, dynamic> json) =>
      TransactionStatus();

  Map<String, dynamic> toMap() => {};
}

class GtinInformationElement {
  GtinInformationElement({
    required this.gtinInformation,
  });

  final GtinInformationGtinInformation gtinInformation;

  factory GtinInformationElement.fromMap(Map<String, dynamic> json) =>
      GtinInformationElement(
        gtinInformation:
            GtinInformationGtinInformation.fromMap(json["gtin_information"]),
      );

  Map<String, dynamic> toMap() => {
        "gtin_information": gtinInformation.toMap(),
      };
}

class GtinInformationGtinInformation {
  GtinInformationGtinInformation({
    required this.ndc,
    required this.brandName,
    required this.dosageForm,
    required this.expDate,
    required this.gtin,
    required this.lotNumber,
    required this.mfgAddress,
    required this.mfgDate,
    required this.mfgGln,
    required this.mfgName,
    required this.productName,
  });

  final String ndc;
  final String brandName;
  final String dosageForm;
  final String expDate;
  final String gtin;
  final String lotNumber;
  final String mfgAddress;
  final String mfgDate;
  final String mfgGln;
  final String mfgName;
  final String productName;

  factory GtinInformationGtinInformation.fromMap(Map<String, dynamic> json) =>
      GtinInformationGtinInformation(
        ndc: json["NDC"],
        brandName: json["brand_name"],
        dosageForm: json["dosage_form"],
        expDate: json["exp_date"],
        gtin: json["gtin"],
        lotNumber: json["lot_number"],
        mfgAddress: json["mfg_address"],
        mfgDate: json["mfg_date"],
        mfgGln: json["mfg_gln"],
        mfgName: json["mfg_name"],
        productName: json["product_name"],
      );

  Map<String, dynamic> toMap() => {
        "NDC": ndc,
        "brand_name": brandName,
        "dosage_form": dosageForm,
        "exp_date": expDate,
        "gtin": gtin,
        "lot_number": lotNumber,
        "mfg_address": mfgAddress,
        "mfg_date": mfgDate,
        "mfg_gln": mfgGln,
        "mfg_name": mfgName,
        "product_name": productName,
      };
}

class LocationTP {
  LocationTP({
    this.currentLocation,
    this.entryPointLocation,
    this.exitPointLocation,
  });

  final TransactionStatus? currentLocation;
  final TransactionStatus? entryPointLocation;
  final TransactionStatus? exitPointLocation;

  factory LocationTP.fromMap(Map<String, dynamic> json) => LocationTP(
        currentLocation: json["current_location"] == null
            ? null
            : TransactionStatus.fromMap(json["current_location"]),
        entryPointLocation: json["entry_point_location"] == null
            ? null
            : TransactionStatus.fromMap(json["entry_point_location"]),
        exitPointLocation: json["exit_point_location"] == null
            ? null
            : TransactionStatus.fromMap(json["exit_point_location"]),
      );

  Map<String, dynamic> toMap() => {
        "current_location":
            currentLocation == null ? null : currentLocation?.toMap(),
        "entry_point_location":
            entryPointLocation == null ? null : entryPointLocation?.toMap(),
        "exit_point_location":
            exitPointLocation == null ? null : exitPointLocation?.toMap(),
      };
}

class Owner {
  Owner({
    this.entryPointOwner,
    this.currentOwner,
    this.exitPointOwer,
  });

  final TransactionStatus? entryPointOwner;
  final TransactionStatus? currentOwner;
  final TransactionStatus? exitPointOwer;

  factory Owner.fromMap(Map<String, dynamic> json) => Owner(
        entryPointOwner: json["entry_point_owner"] == null
            ? null
            : TransactionStatus.fromMap(json["entry_point_owner"]),
        currentOwner: json["current_owner"] == null
            ? null
            : TransactionStatus.fromMap(json["current_owner"]),
        exitPointOwer: json["exit_point_ower"] == null
            ? null
            : TransactionStatus.fromMap(json["exit_point_ower"]),
      );

  Map<String, dynamic> toMap() => {
        "entry_point_owner":
            entryPointOwner == null ? null : entryPointOwner?.toMap(),
        "current_owner": currentOwner == null ? null : currentOwner?.toMap(),
        "exit_point_ower":
            exitPointOwer == null ? null : exitPointOwer?.toMap(),
      };
}

class PackageInformationElement {
  PackageInformationElement({
    required this.packageInformation,
  });

  final PackageInformationPackageInformation packageInformation;

  factory PackageInformationElement.fromMap(Map<String, dynamic> json) =>
      PackageInformationElement(
        packageInformation: PackageInformationPackageInformation.fromMap(
            json["package_information"]),
      );

  Map<String, dynamic> toMap() => {
        "package_information": packageInformation.toMap(),
      };
}

class PackageInformationPackageInformation {
  PackageInformationPackageInformation({
    required this.colour,
    required this.depth,
    required this.height,
    required this.innerSerailCount,
    required this.lotNumber,
    required this.packageGrossWeight,
    required this.packagePalletSn,
    required this.packageType,
    required this.shape,
    required this.ssccNo,
    required this.status,
    required this.totalDimensions,
    required this.width,
  });

  final String colour;
  final String depth;
  final String height;
  final int innerSerailCount;
  final String lotNumber;
  final String packageGrossWeight;
  final int packagePalletSn;
  final String packageType;
  final String shape;
  final String ssccNo;
  final String status;
  final String totalDimensions;
  final String width;

  factory PackageInformationPackageInformation.fromMap(
          Map<String, dynamic> json) =>
      PackageInformationPackageInformation(
        colour: json["colour"],
        depth: json["depth"],
        height: json["height"],
        innerSerailCount: json["inner_serail_count"],
        lotNumber: json["lot_number"],
        packageGrossWeight: json["package_gross_weight"],
        packagePalletSn: json["package_pallet_sn"],
        packageType: json["package_type"],
        shape: json["shape"],
        ssccNo: json["sscc_no"],
        status: json["status"],
        totalDimensions: json["total_dimensions"],
        width: json["width"],
      );

  Map<String, dynamic> toMap() => {
        "colour": colour,
        "depth": depth,
        "height": height,
        "inner_serail_count": innerSerailCount,
        "lot_number": lotNumber,
        "package_gross_weight": packageGrossWeight,
        "package_pallet_sn": packagePalletSn,
        "package_type": packageType,
        "shape": shape,
        "sscc_no": ssccNo,
        "status": status,
        "total_dimensions": totalDimensions,
        "width": width,
      };
}

class Status {
  Status({
    required this.transactionStatus,
  });

  final TransactionStatus transactionStatus;

  factory Status.fromMap(Map<String, dynamic> json) => Status(
        transactionStatus:
            TransactionStatus.fromMap(json["transaction_status"]),
      );

  Map<String, dynamic> toMap() => {
        "transaction_status": transactionStatus.toMap(),
      };
}

class TransactionEvent {
  TransactionEvent({
    required this.transactionEvent,
  });

  final TransactionStatus transactionEvent;

  factory TransactionEvent.fromMap(Map<String, dynamic> json) =>
      TransactionEvent(
        transactionEvent: TransactionStatus.fromMap(json["transaction_event"]),
      );

  Map<String, dynamic> toMap() => {
        "transaction_event": transactionEvent.toMap(),
      };
}
