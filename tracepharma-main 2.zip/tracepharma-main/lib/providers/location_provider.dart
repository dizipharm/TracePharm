import 'package:flutter/foundation.dart';
import 'package:geocoding/geocoding.dart' as geocoding;
import 'package:location/location.dart';

class LocationProvider extends ChangeNotifier {
  String currentLocation = "Unknown!";
  String currentCordinates = "Unknown";

  getLocationData() async {
    Location location = Location();

    bool _serviceEnabled;
    PermissionStatus _permissionGranted;
    LocationData _locationData;

    _serviceEnabled = await location.serviceEnabled();
    if (!_serviceEnabled) {
      _serviceEnabled = await location.requestService();
      if (!_serviceEnabled) {
        return;
      }
    }

    _permissionGranted = await location.hasPermission();
    if (_permissionGranted == PermissionStatus.denied) {
      _permissionGranted = await location.requestPermission();
      if (_permissionGranted != PermissionStatus.granted) {
        return;
      }
    }

    _locationData = await location.getLocation();

    if (_locationData.latitude == null || _locationData.longitude == null) {
      print("no location data");
      return;
    }

    print("${_locationData.latitude} ,${_locationData.longitude}");
    List<geocoding.Placemark> addresses =
        await _getAddress(_locationData.latitude, _locationData.longitude);
    print("6");
    currentLocation = addresses[0].name ?? "Fetching...";
    print(addresses[0].name);
    notifyListeners();
    // update();
  }

  Future<List<geocoding.Placemark>> _getAddress(
      double? lat, double? lang) async {
    List<geocoding.Placemark> addresses =
        await geocoding.placemarkFromCoordinates(lat!, lang!);
    return addresses;
  }
}
