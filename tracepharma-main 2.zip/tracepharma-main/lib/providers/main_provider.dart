import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:tracepharm/model/login_success_response.dart';

class MainProvider extends ChangeNotifier {
  bool _isLoggedIn = false;
  bool _isLoading = false;
  bool get isLoggedIn => _isLoggedIn;
  bool get isLoading => _isLoading;
  setIsLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }

  setIsLoggedIn(bool value) {
    _isLoggedIn = value;
    notifyListeners();
  }

  Future<bool> checkIsLoggedIn() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    bool? isloggedin = prefs.getBool("isLoggedIn");
    if (isloggedin == true) {
      setIsLoggedIn(true);
      return true;
    } else {
      setIsLoggedIn(false);
      return false;
    }

    // SharedPreferences.getInstance().then((preferences) {
    //   bool? isloggedin = preferences.getBool("isLoggedIn");
    //   if (isloggedin == true) {
    //     setIsLoggedIn(true);
    //     return true;
    //   } else {
    //     setIsLoggedIn(false);
    //     return false;
    //   }
    // });
    // return false;
  }

  void login(String email, String password, BuildContext context) async {
    setIsLoading(true);
    try {
      http.Response response = await http.post(
        Uri.parse('http://3.239.56.34:8000/api/auth/login'),
        body: json.encode({'email': email, 'password': password}),
        headers: {'Content-Type': 'application/json'},
      );
      if (response.statusCode == 200) {
        final LoginSuccessResponse loginSuccessResponse =
            loginSuccessResponseFromMap(response.body);
        SharedPreferences pref = await SharedPreferences.getInstance();
        await pref.setString('access', loginSuccessResponse.access);
        await pref.setString('id', loginSuccessResponse.id);
        await pref.setString('first_name', loginSuccessResponse.firstName);
        await pref.setString('last_name', loginSuccessResponse.lastName);
        await pref.setString('email', loginSuccessResponse.email);
        await pref.setString(
            'contact_number', loginSuccessResponse.contactNumber);
        await pref.setString('alternate_contact_number',
            loginSuccessResponse.alternateContactNumber);
        await pref.setString('role', loginSuccessResponse.role);
        await pref.setString('roleType', loginSuccessResponse.roleType);
        await pref.setString(
            'organizationId', loginSuccessResponse.organizationId);
        await pref.setString(
            'organizationCategory', loginSuccessResponse.organizationCategory);
        await pref.setString('companyGln', loginSuccessResponse.companyGln);
        await pref.setString('companyName', loginSuccessResponse.companyName);
        await pref.setString(
            'companyAddress', loginSuccessResponse.companyAddress);
        await pref.setBool('isLoggedIn', true);

        setIsLoggedIn(true);
        setIsLoading(false);
        Navigator.pushReplacementNamed(context, '/home');
      } else {
        setIsLoading(false);
        showDialog(
            context: context,
            builder: (context) {
              return AlertDialog(
                title: const Text('Error'),
                content: const Text('Invalid email or password'),
                actions: <Widget>[
                  TextButton(
                    child: const Text('Ok'),
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                  )
                ],
              );
            });
      }
    } catch (e) {
      showDialog(
          context: context,
          builder: (context) {
            return AlertDialog(
              title: const Text('Something went wrong'),
              content: Text('$e'),
              actions: <Widget>[
                TextButton(
                  child: const Text('Ok'),
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                )
              ],
            );
          });
      print(e.toString());
    }
  }

  Future<LoginSuccessResponse> getValuesFromSharedPref() async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    String? access = pref.getString('access');
    String? id = pref.getString('id');
    String? firstName = pref.getString('first_name');
    String? lastName = pref.getString('last_name');
    String? email = pref.getString('email');
    String? contactNumber = pref.getString('contact_number');
    String? alternateContactNumber = pref.getString('alternate_contact_number');
    String? role = pref.getString('role');
    String? roleType = pref.getString('roleType');
    String? organizationId = pref.getString('organizationId');
    String? organizationCategory = pref.getString('organizationCategory');
    String? companyGln = pref.getString('companyGln');
    String? companyName = pref.getString('companyName');
    String? companyAddress = pref.getString('companyAddress');
    return LoginSuccessResponse(
      message: "From Shared Pref",
      email: email ?? "",
      firstName: firstName ?? "",
      lastName: lastName ?? "",
      contactNumber: contactNumber ?? "",
      alternateContactNumber: alternateContactNumber ?? "",
      id: id ?? "",
      access: access ?? "",
      role: role ?? "",
      roleType: roleType ?? "",
      companyName: companyName ?? "",
      companyAddress: companyAddress ?? "",
      organizationCategory: organizationCategory ?? "",
      organizationId: organizationId ?? "",
      companyGln: companyGln ?? "",
    );
  }
}
