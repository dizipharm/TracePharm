import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:tracepharm/model/package_details.dart';

class TracePharm extends ChangeNotifier {
  getDetailsFromSSCC(String sscc) async {
    http.Response response = await http.get(Uri.parse(
        "http://www.tracepharm.io:5000/api/v1.0.0/exp/package_details/$sscc"));
    if (response.statusCode == 200) {
      final PackageDetailsResponse packageDetailsResponse =
          packageDetailsResponseFromMap(response.body);
      return packageDetailsResponse;
    }
  }

  getDetailsFromBarcode(String uri) async {
    http.Response response = await http.get(Uri.parse(uri));
    if (response.statusCode == 200) {
      final PackageDetailsResponse packageDetailsResponse =
          packageDetailsResponseFromMap(response.body);
      return packageDetailsResponse;
    }
  }
}
